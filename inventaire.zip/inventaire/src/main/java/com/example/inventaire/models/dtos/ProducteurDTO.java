package com.example.inventaire.models.dtos;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProducteurDTO {
    Long Producteurid;
    String nom;
    String prenom;
    String adresse;

    List<InventaireDTO> inventaires;
}
