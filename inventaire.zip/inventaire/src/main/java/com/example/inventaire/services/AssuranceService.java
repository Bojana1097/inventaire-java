package com.example.inventaire.services;

import java.util.List;
import java.util.stream.Collectors;

import com.example.inventaire.mappers.AssuranceMapper;
import com.example.inventaire.models.dtos.AssuranceDTO;
import com.example.inventaire.models.entities.Assurance;
import com.example.inventaire.models.forms.AssuranceForm;
import com.example.inventaire.repositories.AssuranceRepository;
import com.example.inventaire.services.Base.BaseService;

import org.springframework.stereotype.Service;

@Service
public class AssuranceService implements BaseService<AssuranceDTO, AssuranceForm, Long> {
    private final AssuranceMapper assuranceMapper;
    private final AssuranceRepository assuranceRepository;
    
    public AssuranceService(AssuranceRepository assuranceRepository, AssuranceMapper assuranceMapper){
        this.assuranceMapper = assuranceMapper;
        this.assuranceRepository = assuranceRepository;
    }

    public List<AssuranceDTO> getAll(){
        return this.assuranceRepository.findAll()
            .stream()
            .map(this.assuranceMapper::entityToDTO)
            .collect(Collectors.toList());
    }
    public AssuranceDTO getOneById(Long id){
        return this.assuranceMapper.entityToDTO(this.assuranceRepository.findById(id).orElse(null));
    }
    public void insert(AssuranceForm form){
        Assurance a = this.assuranceMapper.formToEntity(form);
        this.assuranceRepository.save(a);
    }

    public void delete(Long id){
        Assurance a = this.assuranceRepository.findById(id).orElse(null);
        this.assuranceRepository.delete(a);
    }

    public AssuranceDTO update(AssuranceForm form, Long id){
        Assurance a = this.assuranceRepository.findById(id).orElse(null);
        
        a.setNumAssurance(form.getNumAssurance());
        a.setDateSouscription(form.getDateSouscription());
        a.setDateFin(form.getDateFin());
        
        this.assuranceRepository.save(a);
        return this.assuranceMapper.entityToDTO(a);
    }

    public  AssuranceDTO getByProducteur(Long producteurId)
    {
        Assurance assurance = this.assuranceRepository.findByProducteurId(producteurId);

        AssuranceDTO dto = assuranceMapper.entityToDTO(assurance);
        
        return dto;
    }
}
