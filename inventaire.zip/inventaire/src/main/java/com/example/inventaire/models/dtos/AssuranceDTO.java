package com.example.inventaire.models.dtos;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AssuranceDTO {
    Long id;
    int numAssurance;
    Date dateSouscription;
    Date dateFin;
    Long producteurId;
}
