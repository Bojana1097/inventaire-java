package com.example.inventaire.services;

import java.util.List;
import java.util.stream.Collectors;

import com.example.inventaire.mappers.AnimalMapper;
import com.example.inventaire.models.dtos.AnimalDTO;
import com.example.inventaire.models.entities.Animal;
import com.example.inventaire.models.forms.AnimalForm;
import com.example.inventaire.repositories.AnimalRepository;
import com.example.inventaire.services.Base.BaseService;

import org.springframework.stereotype.Service;

@Service
public class AnimalService implements BaseService<AnimalDTO, AnimalForm, Long> {
    private final AnimalRepository animalRepository;
    private final AnimalMapper animalMapper;

    public AnimalService(AnimalRepository animalRepository, AnimalMapper animalMapper) {
        this.animalMapper = animalMapper;
        this.animalRepository = animalRepository;
    }

    public List<AnimalDTO> getAll() {
        return this.animalRepository.findAll()
                .stream()
                .map(this.animalMapper::entityToDTO)
                .collect(Collectors.toList());
    }

    public AnimalDTO getOneById(Long id) {
        return this.animalMapper.entityToDTO(this.animalRepository
                                            .findById(id).orElse(null));
    }

    public void insert(AnimalForm form) {
        Animal a = this.animalMapper.formToEntity(form);
        this.animalRepository.save(a);
    }

    @Override
    public void delete(Long id) {
        Animal a = this.animalRepository.findById(id).orElse(null);
        this.animalRepository.delete(a);
    }

    @Override
    public AnimalDTO update(AnimalForm form, Long id) {
        Animal a = this.animalRepository.findById(id).orElse(null);

        a.setAlimentation(form.getAlimentation());
        a.setCategorie(form.getCategorie());
        a.setNom(form.getNom());
        a.setType(form.getType());

        this.animalRepository.save(a);

        return this.animalMapper.entityToDTO(a);
    }
}
