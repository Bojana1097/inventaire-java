package com.example.inventaire.mappers;

import com.example.inventaire.models.dtos.LegumeDTO;
import com.example.inventaire.models.entities.Legume;
import com.example.inventaire.models.forms.LegumeForm;

import org.springframework.stereotype.Service;

@Service
public class LegumeMapper implements BaseMapper<LegumeDTO, LegumeForm, Legume> {
    @Override
    public Legume formToEntity(LegumeForm form) {
        Legume l = new Legume();

        l.setCategorie(form.getCategorie());
        l.setCouleur(form.getCouleur());
        l.setNom(form.getNom());
        l.setQuantite(form.getQuantite());
        l.setSaison(form.getSaison());

        return l;
    }

    @Override
    public Legume dtoToEntity(LegumeDTO dto) {
        Legume l = new Legume();
        if (dto != null && dto.getId() > 0) {
            l.setId(dto.getId());
            l.setNom(dto.getNom());
            l.setCouleur(dto.getCouleur());
            l.setCategorie(dto.getCategorie());
            l.setQuantite(dto.getQuantite());
            l.setSaison(dto.getSaison());
        }
        return l;
    }

    @Override
    public LegumeDTO entityToDTO(Legume entity) {
        if (entity != null && entity.getId() > 0) {
            return LegumeDTO.builder()
                    .id(entity.getId())
                    .categorie(entity.getCategorie())
                    .nom(entity.getNom())
                    .couleur(entity.getCouleur())
                    .quantite(entity.getQuantite())
                    .saison(entity.getSaison())
                    .build();
        }
        return null;
    }
}

