package com.example.inventaire.repositories;

import java.util.List;

import com.example.inventaire.models.entities.Inventaire;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InventaireRepository extends JpaRepository<Inventaire, Long>{
    public List<Inventaire> findByProducteurId(Long id);
}
