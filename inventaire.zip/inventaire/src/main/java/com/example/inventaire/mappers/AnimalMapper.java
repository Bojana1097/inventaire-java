package com.example.inventaire.mappers;

import com.example.inventaire.models.dtos.AnimalDTO;
import com.example.inventaire.models.entities.Animal;
import com.example.inventaire.models.forms.AnimalForm;

import org.springframework.stereotype.Service;

@Service
public class AnimalMapper implements BaseMapper<AnimalDTO, AnimalForm, Animal> {

    @Override
    public Animal formToEntity(AnimalForm form) {
        Animal a = new Animal();

        a.setAlimentation(form.getAlimentation());
        a.setCategorie(form.getCategorie());
        a.setNom(form.getNom());
        a.setType(form.getType());

        return a;
    }

    @Override
    public AnimalDTO entityToDTO(Animal entity) {
        if (entity != null && entity.getId() > 0) {
            return AnimalDTO.builder()
                    .id(entity.getId())
                    .alimentation(entity.getAlimentation())
                    .categorie(entity.getAlimentation())
                    .nom(entity.getNom())
                    .type(entity.getType())
                    .build();
        }
        return null;
    }

    @Override
    public Animal dtoToEntity(AnimalDTO dto) {
        Animal a = new Animal();

        if (dto != null && dto.getId() > 0) {
            a.setAlimentation(dto.getAlimentation());
            a.setId(dto.getId());
            a.setCategorie(dto.getCategorie());
            a.setNom(dto.getNom());
            a.setType(dto.getType());
        }
        return a;
    }
}
