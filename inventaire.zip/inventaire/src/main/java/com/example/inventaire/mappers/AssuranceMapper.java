package com.example.inventaire.mappers;

import com.example.inventaire.models.dtos.AssuranceDTO;
import com.example.inventaire.models.entities.Assurance;
import com.example.inventaire.models.forms.AssuranceForm;

import org.springframework.stereotype.Service;

@Service
public class AssuranceMapper implements BaseMapper<AssuranceDTO, AssuranceForm, Assurance>{
    private final ProducteurMapper producteurMapper;

    public AssuranceMapper(ProducteurMapper producteurMapper)
    {
        this.producteurMapper = producteurMapper;
    }
    @Override
    public Assurance formToEntity(AssuranceForm form){
        Assurance a = new Assurance();

        a.setNumAssurance(form.getNumAssurance());
        a.setDateSouscription(form.getDateSouscription());
        a.setDateFin(form.getDateFin());

        return a;
    }

    @Override
    public AssuranceDTO entityToDTO(Assurance entity){
        if(entity !=null && entity.getId() > 0){
            return AssuranceDTO.builder()
                .dateSouscription(entity.getDateSouscription())
                .numAssurance(entity.getNumAssurance())
                .dateFin(entity.getDateFin())
                .producteurId(entity.getProducteur().getId())
                .build();

                //.producteurId(entity.getProducteur().getId())
        }
        return null;
    }

    @Override
    public Assurance dtoToEntity(AssuranceDTO dto){
        Assurance a = new Assurance();

        if(dto != null && dto.getId() > 0){
            a.setDateFin(dto.getDateFin());
            a.setDateSouscription(dto.getDateSouscription());
            a.setNumAssurance(dto.getNumAssurance());
        }
        return a;
    }
}
    
