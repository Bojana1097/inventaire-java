package com.example.inventaire.models.forms;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FruitForm {
    String nom;
    String couleur;
    String saison;
    String categorie;
    int quantite;
}
