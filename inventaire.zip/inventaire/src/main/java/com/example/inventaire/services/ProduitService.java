package com.example.inventaire.services;

import java.util.List;
import java.util.stream.Collectors;

import com.example.inventaire.mappers.ProduitMapper;
import com.example.inventaire.models.dtos.ProduitDTO;
import com.example.inventaire.models.entities.Produit;
import com.example.inventaire.models.forms.ProduitForm;
import com.example.inventaire.repositories.ProduitRepository;
import com.example.inventaire.services.Base.BaseService;

import org.springframework.stereotype.Service;

@Service
public class ProduitService implements BaseService<ProduitDTO, ProduitForm, Long> {
    private final ProduitRepository produitRepository;
    private final ProduitMapper produitMapper;

    public ProduitService(ProduitRepository produitRepository, ProduitMapper produitMapper) {
        this.produitMapper = produitMapper;
        this.produitRepository = produitRepository;
    }

    public List<ProduitDTO> getAll() {
        return this.produitRepository.findAll()
                .stream()
                .map(this.produitMapper::entityToDTO)
                .collect(Collectors.toList());
    }

    public ProduitDTO getOneById(Long id) {
        return this.produitMapper.entityToDTO(this.produitRepository.findById(id).orElse(null));
    }

    public void insert(ProduitForm form) {
        Produit p = this.produitMapper.formToEntity(form);
        this.produitRepository.save(p);
    }

    @Override
    public void delete(Long id) {
        Produit p = this.produitRepository.findById(id).orElse(null);
        this.produitRepository.delete(p);
    }

    @Override
    public ProduitDTO update(ProduitForm form, Long id) {
        Produit p = this.produitRepository.findById(id).orElse(null);

        p.setDesignation(form.getDesignation());
        p.setNom(form.getNom());
        p.setQuantite(form.getQuantite());

        this.produitRepository.save(p);

        return this.produitMapper.entityToDTO(p);
    }

}
