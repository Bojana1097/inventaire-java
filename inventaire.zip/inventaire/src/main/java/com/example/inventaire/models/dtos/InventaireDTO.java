package com.example.inventaire.models.dtos;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InventaireDTO {
    long id;
    String annee;
    List<FruitDTO> fruits;
    List<LegumeDTO> legumes;
    List<AnimalDTO> animals;
    List<ProduitDTO> produits;
    Long producteurId;
}
