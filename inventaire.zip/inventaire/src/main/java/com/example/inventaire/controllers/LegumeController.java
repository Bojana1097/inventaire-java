package com.example.inventaire.controllers;

import java.util.List;

import javax.validation.Valid;

import com.example.inventaire.models.dtos.LegumeDTO;
import com.example.inventaire.models.forms.LegumeForm;
import com.example.inventaire.services.LegumeService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/Legume")
public class LegumeController {
    private final LegumeService service;

    public LegumeController(LegumeService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List<LegumeDTO>> getAll() {
        return ResponseEntity.ok(service.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<LegumeDTO> getOneById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getOneById(id));
    }

    @PostMapping
    public ResponseEntity<LegumeDTO> insert(@Valid @RequestBody LegumeForm form) {
        service.insert(form);
        return ResponseEntity.ok(null);
    }

    @PutMapping("/{id}")
    public ResponseEntity<LegumeDTO> update(@PathVariable Long id, @Valid @RequestBody LegumeForm form) {
        service.update(form, id);
        return ResponseEntity.ok(null);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Long> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.ok(null);
    }
}