package com.example.inventaire.controllers;

import java.util.List;

import javax.validation.Valid;

import com.example.inventaire.models.dtos.AssuranceDTO;
import com.example.inventaire.models.forms.AssuranceForm;
import com.example.inventaire.services.AssuranceService;
import com.example.inventaire.services.ProducteurService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(originPatterns = "http://localhost:4200")
@RequestMapping("/Assurance")
public class AssuranceController {
    private final AssuranceService assuranceService;
    private final ProducteurService producteurService;

    public AssuranceController(AssuranceService assuranceService, ProducteurService producteurService)
    {
        this.assuranceService = assuranceService;
        this.producteurService = producteurService;
    }
    
    @GetMapping("/producteur/{id}/Assurance")
    public AssuranceDTO  findByProducteur(@PathVariable Long id){
        return assuranceService.getByProducteur(id);
    }

    @GetMapping
    public ResponseEntity<List<AssuranceDTO>> getAll()
    {
        return ResponseEntity.ok(assuranceService.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<AssuranceDTO>getOneById(@PathVariable Long id)
    {
        return ResponseEntity.ok(assuranceService.getOneById(id));
    }

    @PostMapping("/{id}")
    public ResponseEntity<AssuranceDTO> insert(@Valid @RequestBody AssuranceForm form)
    {
        assuranceService.insert(form);
        return ResponseEntity.ok(null);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Long> delete(@PathVariable Long id)
    {
        assuranceService.delete(id);
        return ResponseEntity.ok(null);
    }
    
    
}
