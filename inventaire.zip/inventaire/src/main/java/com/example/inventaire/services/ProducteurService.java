package com.example.inventaire.services;

import java.util.List;
import java.util.stream.Collectors;

import com.example.inventaire.mappers.ProducteurMapper;
import com.example.inventaire.models.dtos.ProducteurDTO;
import com.example.inventaire.models.entities.Producteur;
import com.example.inventaire.models.forms.ProducteurForm;
import com.example.inventaire.repositories.ProducteurRepository;
import com.example.inventaire.services.Base.BaseService;

import org.springframework.stereotype.Service;

@Service
public class ProducteurService implements BaseService<ProducteurDTO, ProducteurForm, Long> {
    private final ProducteurRepository producteurRepository;
    private final ProducteurMapper producteurMapper;

    public ProducteurService(ProducteurRepository producteurRepository, ProducteurMapper producteurMapper) {
        this.producteurMapper = producteurMapper;
        this.producteurRepository = producteurRepository;
    }

    @Override
    public List<ProducteurDTO> getAll() {
        return this.producteurRepository.findAll()
                .stream()
                .map(this.producteurMapper::entityToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public ProducteurDTO getOneById(Long id) {
        return this.producteurMapper.entityToDTO(this.producteurRepository.findById(id).orElse(null));
    }

    @Override
    public void insert(ProducteurForm form) {
        Producteur p = this.producteurMapper.formToEntity(form);
        this.producteurRepository.save(p);
    }

    @Override
    public void delete(Long id) {
        Producteur p = this.producteurRepository.findById(id).orElse(null);
        this.producteurRepository.delete(p);
    }

    @Override
    public ProducteurDTO update(ProducteurForm form, Long id) {
        Producteur p = this.producteurRepository.findById(id).orElse(null);

        p.setNom(form.getNom());
        p.setPrenom(form.getPrenom());
        p.setAdresse(form.getAdresse());

        this.producteurRepository.save(p);
        return this.producteurMapper.entityToDTO(p);
    }
}
