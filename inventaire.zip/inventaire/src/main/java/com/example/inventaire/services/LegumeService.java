package com.example.inventaire.services;

import java.util.List;
import java.util.stream.Collectors;

import com.example.inventaire.mappers.LegumeMapper;
import com.example.inventaire.models.dtos.LegumeDTO;
import com.example.inventaire.models.entities.Legume;
import com.example.inventaire.models.forms.LegumeForm;
import com.example.inventaire.repositories.LegumeRepository;
import com.example.inventaire.services.Base.BaseService;

import org.springframework.stereotype.Service;

@Service
public class LegumeService implements BaseService<LegumeDTO, LegumeForm, Long> {
    private final LegumeRepository legumeRepository;
    private final LegumeMapper legumeMapper;

    public LegumeService(LegumeRepository legumeRepository, LegumeMapper legumeMapper) {
        this.legumeMapper = legumeMapper;
        this.legumeRepository = legumeRepository;
    }

    public List<LegumeDTO> getAll() {
        return this.legumeRepository.findAll()
                .stream()
                .map(this.legumeMapper::entityToDTO)
                .collect(Collectors.toList());
    }

    public LegumeDTO getOneById(Long id) {
        return this.legumeMapper.entityToDTO(this.legumeRepository.findById(id).orElse(null));
    }

    public void insert(LegumeForm form) {
        Legume l = this.legumeMapper.formToEntity(form);
        this.legumeRepository.save(l);
    }

    @Override
    public void delete(Long id) {
        Legume l = this.legumeRepository.findById(id).orElse(null);
        this.legumeRepository.delete(l);
    }

    @Override
    public LegumeDTO update(LegumeForm form, Long id) {
        Legume l = this.legumeRepository.findById(id).orElse(null);

        l.setCategorie(form.getCategorie());
        l.setCouleur(form.getCouleur());
        l.setNom(form.getNom());
        l.setQuantite(form.getQuantite());
        l.setSaison(form.getSaison());

        this.legumeRepository.save(l);

        return this.legumeMapper.entityToDTO(l);
    }
}
