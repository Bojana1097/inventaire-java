package com.example.inventaire.controllers;

import java.util.List;

import javax.validation.Valid;

import com.example.inventaire.models.dtos.AnimalDTO;
import com.example.inventaire.models.dtos.FruitDTO;
import com.example.inventaire.models.dtos.InventaireDTO;
import com.example.inventaire.models.dtos.LegumeDTO;
import com.example.inventaire.models.dtos.ProduitDTO;
import com.example.inventaire.models.forms.InventaireForm;
import com.example.inventaire.services.AnimalService;
import com.example.inventaire.services.FruitService;
import com.example.inventaire.services.InventaireService;
import com.example.inventaire.services.LegumeService;
import com.example.inventaire.services.ProducteurService;
import com.example.inventaire.services.ProduitService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/Inventaire")
public class InventaireController {

        private final InventaireService inventaireService;
        private final FruitService fruitService;
        private final LegumeService legumeService;
        private final ProduitService produitService;
        private final ProducteurService producteurService;
        private final AnimalService animalService;

        public InventaireController(InventaireService inventaireService, FruitService fruitService,
                                LegumeService legumeService, ProduitService produitService, ProducteurService producteurService,
                                AnimalService animalService)
        {
                this.inventaireService = inventaireService;
                this.fruitService = fruitService;
                this.producteurService = producteurService;
                this.animalService = animalService;
                this.legumeService = legumeService;
                this.produitService = produitService;
        }

        @GetMapping("/producteur/{id}/inventaire")
        public List<InventaireDTO> findByProducteur(@PathVariable Long id) {
                return inventaireService.getAllByProducteur(id);

        }



        @GetMapping
        public ResponseEntity<List<InventaireDTO>> getAll() {
                return ResponseEntity.ok(inventaireService.getAll());
        }

        @GetMapping("/{id}")
        public ResponseEntity<InventaireDTO> getOneById(@PathVariable long id) {
                return ResponseEntity.ok(inventaireService.getOneById(id));
        }

        @PostMapping
        public ResponseEntity<InventaireDTO> insert(@Valid @RequestBody InventaireForm form) {
                inventaireService.insert(form);
                return ResponseEntity.ok(null);
        }

        @PutMapping("/{id}")
        public ResponseEntity<InventaireDTO> update(@PathVariable long id, @Valid @RequestBody InventaireForm form) {
                inventaireService.update(form, id);
                return ResponseEntity.ok(null);
        }

        @DeleteMapping("/{id}")
        public ResponseEntity<Long> delete(@PathVariable Long id) {
                inventaireService.delete(id);
                return ResponseEntity.ok(null);
        }

        @GetMapping("inventaire/{id}/fruit")
        public ResponseEntity<List<FruitDTO>> getAllFruitByInventaire(@PathVariable long id)
        {
                List<FruitDTO> fruits = this.inventaireService.getAllFruitByInventaire(id);
                return ResponseEntity.ok(fruits);
        }

        @GetMapping("inventaire/{id}/legume")
        public ResponseEntity<List<LegumeDTO>> getAllLegumeByInventaire(@PathVariable Long id)
        {
                List<LegumeDTO> legumes = this.inventaireService.getAllLegumeByInventaire(id);
                return ResponseEntity.ok(legumes);
        }

        @GetMapping("inventaire/{id}/produit")
        public ResponseEntity<List<ProduitDTO>> getAllProduitByInventaire(@PathVariable Long id)
        {
                List<ProduitDTO> produits = this.inventaireService.getAllProduitByInventaire(id);
                return ResponseEntity.ok(produits);
        }

        @GetMapping("inventaire/{id}/animal")
        public ResponseEntity<List<AnimalDTO>> getAllAnimalByInventaire(@PathVariable Long id)
        {
                List<AnimalDTO> animals = this.inventaireService.getAllAnimalByInventaire(id);
                return ResponseEntity.ok(animals);
        }
}
