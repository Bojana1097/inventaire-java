package com.example.inventaire.models.dtos;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AnimalDTO {
    long id;
     String nom;
     String type;
     String categorie;
     String alimentation;
}
