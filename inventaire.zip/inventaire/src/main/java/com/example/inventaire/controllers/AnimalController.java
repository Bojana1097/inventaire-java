package com.example.inventaire.controllers;

import java.util.List;

import javax.validation.Valid;

import com.example.inventaire.models.dtos.AnimalDTO;
import com.example.inventaire.models.forms.AnimalForm;
import com.example.inventaire.services.AnimalService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/Animal")
public class AnimalController {
    private final AnimalService service;

    public AnimalController(AnimalService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List<AnimalDTO>> getAll() {
        return ResponseEntity.ok(service.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<AnimalDTO> getOneById(@PathVariable long id) {
        return ResponseEntity.ok(service.getOneById(id));
    }

    @PostMapping
    public ResponseEntity<AnimalDTO> insert(@Valid @RequestBody AnimalForm form) {
        service.insert(form);
        return ResponseEntity.ok(null);
    }

    @PutMapping("/{id}")
    public ResponseEntity<AnimalDTO> update(@PathVariable Long id, @Valid @RequestBody AnimalForm form) {
        service.update(form, id);
        return ResponseEntity.ok(null);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Long> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.ok(null);
    }
}