package com.example.inventaire.models.dtos;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LegumeDTO {
    Long id;
    String nom;
    String categorie;
    String couleur;
    String saison;
    int quantite;
}
