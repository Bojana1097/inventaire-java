package com.example.inventaire.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.example.inventaire.mappers.AnimalMapper;
import com.example.inventaire.mappers.FruitMapper;
import com.example.inventaire.mappers.InventaireMapper;
import com.example.inventaire.mappers.LegumeMapper;
import com.example.inventaire.mappers.ProducteurMapper;
import com.example.inventaire.mappers.ProduitMapper;
import com.example.inventaire.models.dtos.AnimalDTO;
import com.example.inventaire.models.dtos.FruitDTO;
import com.example.inventaire.models.dtos.InventaireDTO;
import com.example.inventaire.models.dtos.LegumeDTO;
import com.example.inventaire.models.dtos.ProduitDTO;
import com.example.inventaire.models.entities.Inventaire;
import com.example.inventaire.models.forms.InventaireForm;
import com.example.inventaire.repositories.InventaireRepository;
import com.example.inventaire.services.Base.BaseService;

import org.springframework.stereotype.Service;

@Service

public class InventaireService implements BaseService<InventaireDTO, InventaireForm, Long> {
    private final InventaireRepository inventaireRepository;
    private final InventaireMapper inventaireMapper;
    private final AnimalMapper animalMapper;
    private final LegumeMapper legumeMapper;
    private final ProduitMapper produitMapper;
    private final FruitMapper fruitMapper;
    private final ProducteurMapper producteurMapper;

    public InventaireService(InventaireRepository inventaireRepository, InventaireMapper inventaireMapper,
            AnimalMapper animalMapper, FruitMapper fruitMapper, LegumeMapper legumeMapper,
            ProduitMapper produitMapper, ProducteurMapper producteurMapper) {
        this.inventaireMapper = inventaireMapper;
        this.inventaireRepository = inventaireRepository;
        this.animalMapper = animalMapper;
        this.produitMapper = produitMapper;
        this.fruitMapper = fruitMapper;
        this.legumeMapper = legumeMapper;
        this.producteurMapper = producteurMapper;
    }

    public List<InventaireDTO> getAll() {
        return null;
    }

    public List<InventaireDTO> getAllByProducteur(Long producteurId) {
        List<Inventaire> inventaires = this.inventaireRepository.findByProducteurId(producteurId);

        List<InventaireDTO> dtos = new ArrayList<>();

        for (Inventaire inventaire : inventaires) {
            InventaireDTO dto = InventaireDTO.builder()
                    .animals(inventaire.getAnimals().stream().map(animalMapper::entityToDTO)
                            .collect(Collectors.toList()))
                    .fruits(inventaire.getFruits().stream().map(fruitMapper::entityToDTO)
                            .collect(Collectors.toList()))
                    .legumes(inventaire.getLegumes().stream().map(legumeMapper::entityToDTO)
                            .collect(Collectors.toList()))
                    .produits(inventaire.getProduits().stream().map(produitMapper::entityToDTO)
                            .collect(Collectors.toList()))
                    .producteurId(inventaire.getProducteur().getId())
                    .build();

            dtos.add(dto);
        }
        return dtos;
    }

    @Override
    public InventaireDTO getOneById(Long id) {
        return this.inventaireMapper.entityToDTO(this.inventaireRepository.findById(id).orElse(null));
    }

    @Override
    public void insert(InventaireForm form) {
        Inventaire i = this.inventaireMapper.formToEntity(form);
        this.inventaireRepository.save(i);
    }

    @Override
    public void delete(Long id) {
        Inventaire i = this.inventaireRepository.findById(id).orElse(null);
        this.inventaireRepository.delete(i);
    }

    @Override
    public InventaireDTO update(InventaireForm form, Long id) {
        Inventaire i = this.inventaireRepository.findById(id).orElse(null);

        i.setAnnee(form.getAnnee());

        i = inventaireRepository.save(i);

        return this.inventaireMapper.entityToDTO(i);
    }

    public List<FruitDTO> getAllFruitByInventaire(Long id){
         Inventaire i = this.inventaireRepository.findById(id).orElse(null);

        return i.getFruits().stream().map(fruitMapper::entityToDTO)
            .collect(Collectors.toList());
    }

    public List<LegumeDTO> getAllLegumeByInventaire(Long id){
        Inventaire i = this.inventaireRepository.findById(id).orElse(null);

        return i.getLegumes().stream().map(legumeMapper::entityToDTO)
                .collect(Collectors.toList());
    }

    public List<AnimalDTO> getAllAnimalByInventaire(Long id){
        Inventaire i = this.inventaireRepository.findById(id).orElse(null);

        return i.getAnimals().stream().map(animalMapper::entityToDTO)
                    .collect(Collectors.toList());
    }

    public List<ProduitDTO> getAllProduitByInventaire(Long id)
    {
        Inventaire i = this.inventaireRepository.findById(id).orElse(null);

        return i.getProduits().stream().map(produitMapper::entityToDTO)
                    .collect(Collectors.toList());
    }
}
