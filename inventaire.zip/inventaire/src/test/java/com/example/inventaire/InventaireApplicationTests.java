package com.example.inventaire;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventaireApplicationTests {

	@Test
	void contextLoads() {
	}

}
