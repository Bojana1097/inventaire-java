package com.example.inventaire.models.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity(name = "Animal")
@Table(name = "Animal")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Animal {
    @Id
     @GeneratedValue(strategy = GenerationType.IDENTITY)
     long id;

     @Column(nullable = false)
     String nom;

     @Column(nullable = false)
     String type;

     @Column(nullable = false)
     String categorie;

     @Column(nullable = false)
     String alimentation;
}
