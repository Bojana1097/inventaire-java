package com.example.inventaire.mappers;

import java.util.stream.Collectors;

import com.example.inventaire.models.dtos.InventaireDTO;
import com.example.inventaire.models.entities.Inventaire;
import com.example.inventaire.models.forms.InventaireForm;

import org.springframework.stereotype.Service;

@Service
public class InventaireMapper implements BaseMapper<InventaireDTO, InventaireForm, Inventaire> {
    private final AnimalMapper animalMapper;
    private final LegumeMapper legumeMapper;
    private final FruitMapper fruitMapper;
    private final ProduitMapper produitMapper;

    public InventaireMapper(AnimalMapper animalMapper, LegumeMapper legumeMapper, FruitMapper fruitMapper,
            ProduitMapper produitMapper) {
        this.animalMapper = animalMapper;
        this.legumeMapper = legumeMapper;
        this.fruitMapper = fruitMapper;
        this.produitMapper = produitMapper;

    }

    @Override
    public Inventaire formToEntity(InventaireForm form) {
        Inventaire i = new Inventaire();

        i.setAnnee(form.getAnnee());
        return i;
    }

    @Override
    public InventaireDTO entityToDTO(Inventaire entity) {
        if (entity != null && entity.getId() > 0) {
            return InventaireDTO.builder()
                    .annee(entity.getAnnee())
                    .id(entity.getId())
                    .fruits(entity.getFruits().stream()
                            .map(f -> fruitMapper.entityToDTO(f))
                            .collect(Collectors.toList()))
                    .legumes(entity.getLegumes().stream()
                            .map(l -> legumeMapper.entityToDTO(l))
                            .collect(Collectors.toList()))
                    .produits(entity.getProduits().stream()
                            .map(p -> produitMapper.entityToDTO(p))
                            .collect(Collectors.toList()))
                    .animals(entity.getAnimals().stream()
                            .map(a -> animalMapper.entityToDTO(a))
                            .collect(Collectors.toList()))
                    .build();

        }
        return null;

    }

    @Override
    public Inventaire dtoToEntity(InventaireDTO dto) {
        return null;

    }

}