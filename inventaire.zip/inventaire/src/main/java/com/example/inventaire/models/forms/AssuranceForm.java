package com.example.inventaire.models.forms;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AssuranceForm {
    int numAssurance;
    Date dateSouscription;
    Date dateFin;
    ProducteurForm Producteur;
}
