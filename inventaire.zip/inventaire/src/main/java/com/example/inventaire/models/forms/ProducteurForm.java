package com.example.inventaire.models.forms;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProducteurForm {
    String nom;
    String prenom;
    String adresse;
    InventaireForm inventaire;
}
