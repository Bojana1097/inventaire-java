package com.example.inventaire.services;

import java.util.List;
import java.util.stream.Collectors;

import com.example.inventaire.mappers.FruitMapper;
import com.example.inventaire.models.dtos.FruitDTO;
import com.example.inventaire.models.entities.Fruit;
import com.example.inventaire.models.forms.FruitForm;
import com.example.inventaire.repositories.FruitRepository;
import com.example.inventaire.services.Base.BaseService;

import org.springframework.stereotype.Service;

@Service
public class FruitService implements BaseService<FruitDTO, FruitForm, Long> {
    private final FruitRepository fruitRepository;
    private final FruitMapper fruitMapper;

    public FruitService(FruitRepository fruitRepository, FruitMapper fruitMapper) {
        this.fruitMapper = fruitMapper;
        this.fruitRepository = fruitRepository;
    }

    public List<FruitDTO> getAll() {
        return this.fruitRepository.findAll()
                .stream()
                .map(this.fruitMapper::entityToDTO)
                .collect(Collectors.toList());
    }

    public FruitDTO getOneById(Long id) {
        return this.fruitMapper.entityToDTO(this.fruitRepository.findById(id).orElse(null));
    }

    public void insert(FruitForm form) {
        Fruit f = this.fruitMapper.formToEntity(form);
        this.fruitRepository.save(f);
    }

    @Override
    public void delete(Long id) {
        Fruit f = this.fruitRepository.findById(id).orElse(null);
        this.fruitRepository.delete(f);
    }

    @Override
    public FruitDTO update(FruitForm form, Long id) {
        Fruit f = this.fruitRepository.findById(id).orElse(null);

        f.setCategorie(form.getCategorie());
        f.setCouleur(form.getCouleur());
        f.setSaison(form.getSaison());
        f.setQuantite(form.getQuantite());
        f.setNom(form.getNom());

        this.fruitRepository.save(f);

        return this.fruitMapper.entityToDTO(f);
    }

}
