package com.example.inventaire.controllers;

import java.util.List;

import javax.validation.Valid;

import com.example.inventaire.models.dtos.ProducteurDTO;
import com.example.inventaire.models.forms.ProducteurForm;
import com.example.inventaire.services.InventaireService;
import com.example.inventaire.services.ProducteurService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/Producteur")
public class ProducteurController {

    private final ProducteurService producteurService;
    private final InventaireService inventaireService;

    public ProducteurController(ProducteurService producteurService, InventaireService inventaireService) {
        this.producteurService = producteurService;
        this.inventaireService = inventaireService;
    }

    @GetMapping
    public ResponseEntity<List<ProducteurDTO>> getAll() {
        return ResponseEntity.ok(producteurService.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProducteurDTO> getOneById(@PathVariable long id) {
        return ResponseEntity.ok(producteurService.getOneById(id));
    }

    @PostMapping
    public ResponseEntity<ProducteurDTO> insert(@Valid @RequestBody ProducteurForm form){
        producteurService.insert(form);
        return ResponseEntity.ok(null);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ProducteurDTO> update(@PathVariable Long id, ProducteurForm form) {
        producteurService.update(form, id);
        return ResponseEntity.ok(null);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Long> delete(@PathVariable Long id) {
        producteurService.delete(id);
        return ResponseEntity.ok(null);
    }

}
