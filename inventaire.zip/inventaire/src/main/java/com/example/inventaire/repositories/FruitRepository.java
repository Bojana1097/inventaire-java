package com.example.inventaire.repositories;

import com.example.inventaire.models.entities.Fruit;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FruitRepository extends JpaRepository<Fruit, Long>{
    
}
