package com.example.inventaire.repositories;

import com.example.inventaire.models.entities.Assurance;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AssuranceRepository extends JpaRepository<Assurance, Long>{
    public Assurance findByProducteurId(Long id);
}
