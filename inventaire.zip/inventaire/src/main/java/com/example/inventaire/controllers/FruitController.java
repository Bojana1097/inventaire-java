package com.example.inventaire.controllers;

import java.util.List;

import javax.validation.Valid;

import com.example.inventaire.models.dtos.FruitDTO;
import com.example.inventaire.models.forms.FruitForm;
import com.example.inventaire.services.FruitService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/Fruit")
public class FruitController {
    private final FruitService service;

    public FruitController(FruitService service) {
        this.service = service;
    }

    @GetMapping
    public ResponseEntity<List<FruitDTO>> getAll() {
        return ResponseEntity.ok(service.getAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<FruitDTO> getOneById(@PathVariable Long id)
    {
        return ResponseEntity.ok(service.getOneById(id));
    }

    @PostMapping
    public ResponseEntity<FruitDTO> insert(@Valid @RequestBody FruitForm form) {
        service.insert(form);
        return ResponseEntity.ok(null);
    }

    @PutMapping("/{id}")
    public ResponseEntity<FruitDTO> update(@PathVariable Long id, @Valid @RequestBody FruitForm form) {
        service.update(form, id);
        return ResponseEntity.ok(null);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Long> delete(@PathVariable Long id)
    {
        service.delete(id);
        return ResponseEntity.ok(null);
    }
}