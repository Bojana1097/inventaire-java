package com.example.inventaire.mappers;

import com.example.inventaire.models.dtos.FruitDTO;
import com.example.inventaire.models.entities.Fruit;
import com.example.inventaire.models.forms.FruitForm;

import org.springframework.stereotype.Service;

@Service
public class FruitMapper implements BaseMapper<FruitDTO, FruitForm, Fruit> {

    @Override
    public Fruit formToEntity(FruitForm form) {
        Fruit f = new Fruit();

        f.setCategorie(form.getCategorie());
        f.setCouleur(form.getCouleur());
        f.setNom(form.getNom());
        f.setQuantite(form.getQuantite());
        f.setSaison(form.getSaison());

        return f;
    }

    @Override
    public FruitDTO entityToDTO(Fruit entity) {
        if (entity != null && entity.getId() > 0) {
            FruitDTO DTO = FruitDTO.builder()
                    .id(entity.getId())
                    .categorie(entity.getCategorie())
                    .couleur(entity.getCouleur())
                    .nom(entity.getNom())
                    .quantite(entity.getQuantite())
                    .saison(entity.getSaison())
                    .build();
        }
        return null;
    }

    @Override
    public Fruit dtoToEntity(FruitDTO dto) {
        Fruit f = new Fruit();

        if (dto != null && dto.getId() > 0) {
            f.setId(dto.getId());
            f.setCategorie(dto.getCategorie());
            f.setNom(dto.getNom());
            f.setCouleur(dto.getCouleur());
            f.setSaison(dto.getSaison());
            f.setQuantite(dto.getQuantite());
        }
        return f;
    }

}

