package com.example.inventaire.mappers;

public interface BaseMapper<TDTO, TFORM, TENTITY>{
    public TENTITY formToEntity(TFORM form);
    public TDTO entityToDTO(TENTITY entity);
    public TENTITY dtoToEntity(TDTO dto);
}