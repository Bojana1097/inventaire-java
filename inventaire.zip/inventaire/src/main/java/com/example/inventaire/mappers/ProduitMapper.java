package com.example.inventaire.mappers;

import com.example.inventaire.models.dtos.ProduitDTO;
import com.example.inventaire.models.entities.Produit;
import com.example.inventaire.models.forms.ProduitForm;

import org.springframework.stereotype.Service;

@Service
public class ProduitMapper implements BaseMapper<ProduitDTO, ProduitForm, Produit> {

    @Override
    public Produit formToEntity(ProduitForm form) {
        Produit p = new Produit();

        p.setDesignation(form.getDesignation());
        p.setNom(form.getNom());
        
        p.setQuantite(form.getQuantite());

        return p;
    }

    @Override
    public ProduitDTO entityToDTO(Produit entity) {
        if (entity != null && entity.getId() > 0) {
            return ProduitDTO.builder()
                    .id(entity.getId())
                    .designation(entity.getDesignation())
                    .nom(entity.getNom())
                    .quantite(entity.getQuantite())
                    .build();
        }
        return null;
    }

    @Override
    public Produit dtoToEntity(ProduitDTO dto) {
        Produit p = new Produit();

        if (dto != null & dto.getId() > 0) {
            p.setId(dto.getId());
            p.setDesignation(dto.getDesignation());
            p.setNom(dto.getNom());
            p.setQuantite(dto.getQuantite());
        }
        return p;
    }
}
