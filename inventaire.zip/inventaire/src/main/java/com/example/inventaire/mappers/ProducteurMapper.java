package com.example.inventaire.mappers;

import java.util.stream.Collectors;

import com.example.inventaire.models.dtos.ProducteurDTO;
import com.example.inventaire.models.entities.Producteur;
import com.example.inventaire.models.forms.ProducteurForm;

import org.springframework.stereotype.Service;

@Service
public class ProducteurMapper implements BaseMapper<ProducteurDTO, ProducteurForm, Producteur> {

    private final InventaireMapper inventaireMapper;

    public ProducteurMapper(InventaireMapper inventaireMapper) {
        this.inventaireMapper = inventaireMapper;
    }

    @Override
    public Producteur formToEntity(ProducteurForm form) {
        Producteur pr = new Producteur();

        pr.setAdresse(form.getAdresse());
        pr.setNom(form.getNom());
        pr.setPrenom(form.getPrenom());

        return pr;
    }

    @Override
    public ProducteurDTO entityToDTO(Producteur entity) {
        if (entity != null && entity.getId() > 0) {
            return ProducteurDTO.builder()
                    .nom(entity.getPrenom())
                    .prenom(entity.getAdresse())
                    .inventaires(entity.getInventaires()
                            .stream()
                            .map(i -> inventaireMapper.entityToDTO(i))
                            .collect(Collectors.toList()))
                    .build();
        }
        return null;
    }

    @Override
    public Producteur dtoToEntity(ProducteurDTO dto) {
        return null;
    }
}

