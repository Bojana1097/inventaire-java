package com.example.inventaire.models.forms;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LegumeForm {
    String nom;
    String categorie;
    String couleur;
    String saison;
    int quantite;
}
